<!DOCTYPE HTML>
<html>
<head>
<title>Alphabetize Signs</title>
</head>

<body>
	<h1>Alphabetize Signs</h1> <br />
	<hr />

	
	<?php
		$DisplayForm = TRUE;
		$Number = "";
		
		if (isset($_POST['Submit'])) {
			
			$signs = explode(",", $_POST['signs_input']);
			switch (count($signs)) {
				case 12:
					sort($signs);
					echo "<strong>Alphabetized Signs</strong>";
					echo "<pre>\n";
					print_r($signs);
					echo "</pre>\n";
			}
			



		}
		else
		{
			echo "Please enter the 12 zodiac signs in random order, separated by a comma.";
			echo "Once you submit the form, they will be displayed in alphabetical order.";
		}
		
		if ($DisplayForm) {
			?>
			<form name="AlphabetizeSigns" action="AlphabetizeSigns.php" method="post">
			<br />
			<label for="signs_input">Enter the twelve signs separated by commas:</label><br />
			<textarea name="signs_input" id="signs_input" rows="2" cols="50"><?php echo $_POST['signs_input'];?></textarea>
			<p><input type="reset" value="Clear Form" />&nbsp;
			&nbsp;<input type="submit" name="Submit" value="Send Form" /></p>
			</form>
			<?php

	
		} else {
			

		}
	?>	
</body>

</html>