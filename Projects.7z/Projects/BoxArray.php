<!DOCTYPE HTML>

<html>
<!--
Author: Damian Archer
Course: CIS 333 PHP Programming
Date: 8-8-2022
Assignment: Chapter 6 - BoxArray.php
-->
<head>
<title>Box Array</title>
</head>

<body>
<?php

	$boxArray = array(
				array("", "Length", "Width", "Depth"),
				array("Small box", 12, 10, 2.5),
				array("Medium box", 30, 20, 4),
				array("Large box", 60, 40, 11.5));
				
	echo "<table border=\"1\" width=\"100%\" style=\"background-color:lightgray\">\n";
	
		foreach($boxArray as $row)
		{
			echo "<tr>\n";
			foreach($row as $item) {
				if (!is_numeric($item)) // since all data besides fields are numeric, this works here.
					echo "<td><strong>" . htmlentities($item) . "</strong></td>";
				else
					echo "<td>" . htmlentities($item) . "</strong></td>";
			}
			echo "</tr>\n";
		}
?>

</body>

</html>