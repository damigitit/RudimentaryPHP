<!DOCTYPE HTML>
<html>
<head>
<title>Zodiac Gallery</title>
</head>

<body>
	<?php
		$Dir = "images/zodiac";
		$image_array = array();
		$image_array = scandir($Dir . "/images");
		$image_array = array_diff($image_array, array(".", ".."));
		
		$captions = file("images/zodiac_captions.txt");
		
		$image_array = array(
		$image_array[2] => $captions[0],
		$image_array[3] => $captions[1],
		$image_array[4] => $captions[2],
		$image_array[5] => $captions[3],
		$image_array[6] => $captions[4],
		$image_array[7] => $captions[5],
		$image_array[8] => $captions[6],
		$image_array[9] => $captions[7],
		$image_array[10] => $captions[8],
		$image_array[11] => $captions[9],
		$image_array[12] => $captions[10],
		$image_array[13] => $captions[11]);
		
	#	echo "<pre>";
	#	print_r($image_array);
	#	echo "</pre>";
		
		echo "<table>";
		$counter = 0;
?>

<table width = "100%" border = "1">

<tr>
<?php
		foreach($image_array as $image => $caption)
		{
			if ($counter%4 == 0)
			{
				echo "</tr><tr>";
			}
			echo "<td>";
			#echo $Dir . "/full_size/" . $image;
			echo "<a href='" . $Dir . "/full_size/" . $image . "' target='_blank'/>";
			echo "<img src='" . $Dir . "/images/" . $image . "'/>";
			echo "</a><br />";
			echo $caption;
			echo "</td>";
			++$counter;
		}
		echo "</table>";

		
	?>	
</body>

</html>