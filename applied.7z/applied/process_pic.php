<!DOCTYPE html>
<html lang = "en">
<head>
<title>Process Pic</title>
<meta http-equiv="content-type" 
	content= "text/html; charset = iso-8859-1" />
</head>
<body>
<?php
     //set the value of the tracking variable to TRUE
	$showForm = TRUE;
	if (isset($_POST['upload_image']))
	{
		//process the script
		$showForm = FALSE;
		$Dir = "images";
		//assign the image type to a variable
		$image_name = basename($_FILES['image_file']['name']);
		$image_ext = substr($image_name, strrpos($image_name, '.') + 1);
		$output = substr(basename($_FILES['image_file']['name']), 0, strrpos($image_name, '.'));
			echo "<p>This is the image extension: " . $image_ext . "</p>\n";
		$image_size = $_FILES['image_file']['size'];
			echo "<p>This is the file size: " . $image_size . "</p>\n";
			
		if ($image_ext == "png" || $image_ext == "jpg" || $image_ext == "gif" || $image_ext == "jpeg"){
			echo "<p>The file is an image.</p>\n";
		}
		else {
			echo "<p>You may only upload gif, jpeg, jpg or png files.</p>\n";
			$showForm = TRUE;
		}		
		
		if ($image_size < 75000){
			//try moving the image to the images folder
			echo "<p>Image is less than 25,000 bytes.</p>\n";
			$showForm = FALSE;
				if (move_uploaded_file($_FILES['image_file']['tmp_name'], $Dir . "/" . $_FILES['image_file']['name']) == TRUE){
					echo "File \"" . htmlentities($_FILES['image_file']['name']) . "\" successfully uploaded.<br/>\n";
					echo "<a href = \"process_pic.php\" alt = \"Upload another image\">Upload Another Image</a><br/>\n";
					echo "<p><a href = \"view_high_school_reunion.php\">View All Images</a></p>\n";
					$showForm = FALSE;
				}
				else{
					echo "There was an error uploading the file. <br/>\n";
					$showForm = TRUE;
				}
		}
		else{
			echo "<p>File must be less than 25,000 bytes.</p>\n";
			$showForm = TRUE;
		}
	}
	//if the $showForm variable has a value of true, display the form
if (empty($_POST['comment']))
     {
	echo "<p>Click <a href='PhotoComments.html'>Add a Photo Comment</a> to write your comment to a text file</p>\n";
     }
else {
	$comment = $_POST['comment'];
	echo "<p>Thank you for uploading the comment: " . $comment . "</p>\n";
}
		//opens the handle to the text file in append binary mode
		
        if (empty($output))	
		{
			echo "\$output was empty";
		}
		else
		{
			$PhotoComments = fopen("descriptions/" . $output. ".txt", "ab");
		
			//if the text file is writeable (permissions have been set)
			if (is_writeable("descriptions/" . $output . ".txt")) 
				{
					//lock the file so multiple users cannot modify the file at the same time
					if(flock($PhotoComments, LOCK_EX))
					{
						
						if (fwrite($PhotoComments, $_POST['last_name'] . ", " . $_POST['first_name'] . "\n"))
						{
							echo "<p>Your name has been added for this photo.</p>\n";
							# echo "<p><a href = 'display_photo_comments.php' />View Photo Comments</a></p>\n";
						}
						else
						{
						    //if the comment cannot be written
							echo "<p>Cannot add your name to the photo.</p>\n";
						}
					    //if the comment can be written
						if (fwrite($PhotoComments, $comment . "\n"))
						{
							echo "<p>Your description has been added for this photo.</p>\n";
							# echo "<p><a href = 'display_photo_comments.php' />View Photo Comments</a></p>\n";
						}
						else
						{
						    //if the comment cannot be written
							echo "<p>Cannot add your description.</p>\n";
						}
				    } //ends if flock
					else
					{
					    echo "Error locking file!";
					}
				} //ends if is writeable
			else
				{
					echo "<p>Cannot write to the file.</p>\n";
				}
				//closes the handle to the text file
				fclose($PhotoComments);
				
		}		
		if($showForm){
			//advanced escaping from PHP to code form
			?>
			<form name = "ProcessPic" action = "process_pic.php" method = "post" enctype = "multipart/form-data">
			<!-- <input type = "hidden" name = "MAX_FILE_SIZE" value = "25000" /><br /> -->
			Picture to upload: <br/>
				<p> First Name <input type="text" name="first_name"/></p>
				<p> Last Name <input type="text" name="last_name"/></p>
				<p> Description <textarea name = "comment" cols = "50" rows = "3"></textarea></p>
				<p> File to Upload <input type="file" name="image_file" /><br /></p>
				<input type="submit" name="upload_image" value="Submit"/>
			<br/>
			</form>
		<?php
			}
		?>
</body>
</html>