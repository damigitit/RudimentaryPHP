<?php
	$DirImages = "images";
	$DirDescriptions  = "descriptions";
	
	if (is_dir($DirImages))
		{
			$images = scandir($DirImages);
			$descriptions_files = scandir($DirDescriptions);
			//print_r($images);	
			$count = count($images);
			
			for ($i = 0; $i < $count; $i++)
			{
				if ($images[$i] != "." && $images[$i] !== '..'){
					echo "<figure style='display: inline-block;'>
							<img src = 'images/$images[$i]'>";
					if (file_exists('descriptions/' . $descriptions_files[$i]))
					{

						$descriptions = file('descriptions/' . $descriptions_files[$i]);
						if (is_array($descriptions)){
							$descriptions_count = count($descriptions);
							for ($j = 0; $j < $descriptions_count; $j++)
							{
								echo "<figcaption>$descriptions[$j]</figcaption><br />";
							}
							echo "</figure>\n";
						}
						
					}	
					else
						{
						echo "<p>There are no comments to display</p>";
						}	
				}
			

			}
	    } //ends if statement checking for directory
	else
		{
			echo "<p>There are no images to view.</p>\n";
		}
?>