<?php
	$Dir = "images";
	if (is_dir($Dir))
		{
			$images = scandir($Dir);
			//print_r($images);	
			$comments = file("images/photo_comments.txt");
			$count = count($images);
			
			for ($i = 0; $i < $count; $i++)
			{
				if ($images[$i] != "." && $images[$i] !== '..'){
					echo "<figure>
							<img src = 'images/$images[$i]'>
							<figcaption>$comments[$i]</figcaption>
						</figure>\n";
				}

			}
	    } //ends if statement checking for directory
	else
		{
			echo "<p>There are no images to view.</p>\n";
		}
?>