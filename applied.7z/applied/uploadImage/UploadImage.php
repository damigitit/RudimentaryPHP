<!DOCTYPE html>
<html lang = "en">
<head>
<title>Upload an Image</title>
<meta http-equiv="content-type" 
	content= "text/html; charset = iso-8859-1" />
</head>
<body>
<?php
     //set the value of the tracking variable to TRUE
	$showForm = TRUE;
	if (isset($_POST['upload_image']))
	{
		//process the script
		$showForm = FALSE;
		$Dir = "images";
		//assign the image type to a variable
		$image_name = basename($_FILES['image_file']['name']);
		$image_ext = substr($image_name, strrpos($image_name, '.') + 1);
			echo "<p>This is the image extension: " . $image_ext . "</p>\n";
		$image_size = $_FILES['image_file']['size'];
			echo "<p>This is the file size: " . $image_size . "</p>\n";
			
		if ($image_ext == "png" || $image_ext == "jpg" || $image_ext == "gif" || $image_ext == "jpeg"){
			echo "<p>The file is an image.</p>\n";
		}
		else {
			echo "<p>You may only upload gif, jpeg, jpg or png files.</p>\n";
			$showForm = TRUE;
		}		
		if ($image_size < 75000){
			//try moving the image to the images folder
			echo "<p>Image is less than 25,000 bytes.</p>\n";
			$showForm = FALSE;
				if (move_uploaded_file($_FILES['image_file']['tmp_name'], $Dir . "/" . $_FILES['image_file']['name']) == TRUE){
					echo "File \"" . htmlentities($_FILES['image_file']['name']) . "\" successfully uploaded.<br/>\n";
					echo "<a href = \"UploadImage.php\" alt = \"Upload another image\">Upload Another Image</a><br/>\n";
					echo "<p><a href = \"viewAllImages.php\">View All Images</a></p>\n";
					$showForm = FALSE;
				}
				else{
					echo "There was an error uploading the file. <br/>\n";
					$showForm = TRUE;
				}
		}
		else{
			echo "<p>File must be less than 25,000 bytes.</p>\n";
			$showForm = TRUE;
		}
	}
	//if the $showForm variable has a value of true, display the form

		if($showForm){
			//advanced escaping from PHP to code form
			?>
			<form name = "UploadImage" action = "UploadImage.php" method = "post" enctype = "multipart/form-data">
			<!-- <input type = "hidden" name = "MAX_FILE_SIZE" value = "25000" /><br /> -->
			File to upload: <br/>
			<input type = "file" name = "image_file" /><br />
			(25,000 byte limit) <br/>
			<input type = "submit" name = "upload_image" value = "Upload the Image" />
			<br/>
			</form>
		<?php
			}
		?>
</body>
</html>