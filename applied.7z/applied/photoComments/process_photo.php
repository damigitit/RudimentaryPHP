<!DOCTYPE html>
<html lang = "en">
<head>
<title>Add Comment</title>
</head>
<body>
<?php
//If the value posted from the Web form is empty
if (empty($_POST['comment']))
     {
	echo "<p>Click <a href='PhotoComments.html'>Add a Photo Comment</a> to write your comment to a text file</p>\n";
     }
else {
	$comment = $_POST['comment'];
	echo "<p>Thank you for uploading the comment: " . $comment . "</p>\n";
}
		//opens the handle to the text file in append binary mode
        $PhotoComments = fopen("photo_comments.txt", "ab");
		
			//if the text file is writeable (permissions have been set)
			if (is_writeable("photo_comments.txt")) 
				{
					//lock the file so multiple users cannot modify the file at the same time
					if(flock($PhotoComments, LOCK_EX))
					{
					    //if the comment can be written
						if (fwrite($PhotoComments, $comment . "\n"))
						{
							echo "<p>Your comment has been added to our list of comments.</p>\n";
							echo "<p><a href = 'display_photo_comments.php' />View Photo Comments</a></p>\n";
						}
						else
						{
						    //if the comment cannot be written
							echo "<p>Cannot add your comment to the photo.</p>\n";
						}
				    } //ends if flock
					else
					{
					    echo "Error locking file!";
					}
				} //ends if is writeable
			else
				{
					echo "<p>Cannot write to the file.</p>\n";
				}
				//closes the handle to the text file
				fclose($PhotoComments);
	?>			
</body>
</html>