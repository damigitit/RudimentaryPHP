<?php

echo "<h1>Using the readfile() function</h1>";
$filename = 'photo_comments.txt';
if (file_exists($filename))
{
	echo "<pre>";
    readfile(($filename));
    echo "</pre>";
}

?>