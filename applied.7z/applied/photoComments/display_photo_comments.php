<?php

echo "<h1>Using the file_get_contents() function</h1>";
//using the file_get_contents() function
$filename = 'photo_comments.txt';
if (file_exists($filename))
{
   $display_photo_comments = file_get_contents($filename);
   echo stripslashes($display_photo_comments);
}
else
{
echo "<p>The photo comments cannot be displayed at this time</p>\n";
}


echo "<h1>Using the readfile() function</h1>";
$filename = 'photo_comments.txt';
if (file_exists($filename))
{
	echo "<pre>";
    readfile(($filename));
    echo "</pre>";
}
else
{
  echo "<p>The photo comments cannot be displayed at this time</p>\n";
}

echo "<h1>Using the file function</h1>";
$filename = $_FILES['new_file']['name'];
if (file_exists($filename))
{
$comments = file("photo_comments.txt");
	if(is_array($comments))
	{
		//display the contents
		//troubleshooting technique
		echo "<pre>";
			 print_r($comments);
		echo "</pre>";
		//use a foreach loop to iterate through each element of the array
		foreach ($comments as $newcomments)
		{
		echo "<p>" . stripslashes($newcomments) . "</p>";
		}
	}
}
else
{
echo "<p>There are no comments to display</p>";
}
?>