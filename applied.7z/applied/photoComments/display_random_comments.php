<!DOCTYPE html>
<html lang = "en">
<head>
<title>Random Photo Comments</title>
<meta http-equiv="content-type"
	content="text/html; charset=iso-8859-1" />
</head>
<body>
<?php

   $filename = 'photo_comments.txt';
   
      if(file_exists($filename))
      {
         //check that the file is readable
         if (is_readable($filename))
         {
             //assign the contents of the file to an array variable
             $comment_array = file($filename);
			 
             //echo "<pre>";
			 //print_r($comment_array);
	         //echo "</pre>";
	     
	       //foreach($comment_array as $comments)
	          //{
	             //echo "<p>" . $comments . "</p>\n";
	          //}
	      
	      $comment_count=count($comment_array);
	      //echo "<p>There are " . $comment_count . ' elements in the $comment_array array.</p>'. "\n";
	      $RandomArrayIndex = rand(0, $comment_count-1);
	      //echo "<p>The Random Number is: " . $RandomArrayIndex . ".</p>\n";
	      //strip the backslashes
	      $Comment = stripslashes($comment_array[$RandomArrayIndex]);
	      //display the random comment on the Web page
	      echo "<h2 style = 'text-align:center'>Randomly Displayed Photo Comment</h2>\n";
	      echo "<p style = 'text-align:center'>" . $Comment . "</p>\n"; 
         }
         else
         {
          //specify that the comments cannot be read
          echo "<p>The comments cannot be read at this time</p>\n";
         }
      }
      else
      {
         //specify that there are no comments 
         echo "<p>There are not comments to display.</p>\n";
      }
   

?>
</body>
</html>