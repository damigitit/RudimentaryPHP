<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
<title>Song Organizer</title>
<meta http-equiv="Content-Type"
	content="text/html; charset=iso-8859-1"/>
</head>

<!--
Sample Code
-->

<body>
<h1>Song Organizer</h1>
<?php
//action is for the hyperlink -- like ?page
if(isset($_GET['action'])) {
    //if the file songs.txt exists and is not blank
	if((file_exists("SongOrganizer/songs.txt")) && (filesize("SongOrganizer/songs.txt")!=0)) {

		//Gets the songs and puts them in an indexed array
		$song_array = file("SongOrganizer/songs.txt");

		//use troubleshooting technique to see if the array contains values
		//echo "<pre>";
		    //print_r($song_array);
		//echo "</pre>";


		//the switch statment checks to see which of the actions has been clicked and performs those steps
		//NOTHING HAPPENS HERE UNLESS A ACTION HYPERLINK HAS BEEN CLICKED
		switch ($_GET['action']) {

		case 'Remove_Duplicates': //removes duplicates from the songorganizer
			$song_array = array_unique($song_array); //The array_unique() is used to remove duplicate values from an array
			$song_array = array_values($song_array);//assigns all the values of the array to $song_array -- but no indexese
			break;

		case 'Sort_Ascending'://sorts songarray ascending
			sort($song_array);//sorts the array by values
			break;

		case 'Shuffle'://shuffles the song names
			shuffle($song_array);//The shuffle() function randomizes the order of the elements
			break;
		}//end of switch statement


		//the contents of the songs.txt file are in an ndexed array
		if (count($song_array)>0) {

		    //
			$new_songs = implode($song_array);//turns the indexed array into a string so it can be saved to the text file
			//Opens a handle to the songs.txt file in write binary mode
			$song_store = fopen("SongOrganizer/songs.txt", "wb");

			if($song_store ===false){
				echo "There was an error updating the song file\n";
			}//end of inner if

			else{
				fwrite($song_store, $new_songs);
				fclose($song_store);
			}//end of inner else

		}//end of if (count($song_array)>0)
	else{
			unlink("SongOrganizer/songs.txt");
		}//end of else
	}//end of if((file_exists))
}//end of if(isset($_GET['action']))


if(isset($_POST['submit'])) {//handling any data submitted from web form
	$songs_to_add = stripslashes($_POST['SongName']) . "\n";
	$existing_songs = array();

	if(file_exists("SongOrganizer/songs.txt") && filesize("SongOrganizer/songs.txt")>0) {
		$existing_songs = file("SongOrganizer/songs.txt");
	}//end of if file exists

	if (in_array($songs_to_add, $existing_songs)) {//checks to see if the song name is already in list
		echo "<p>The song you entered already exists! <br />\n";
		echo "Your Song was not added to the list.</p>";
	}//end of if in_array

	else{//adds new song to song list
		$song_file = fopen("SongOrganizer/songs.txt", "ab");

		if ($song_file ===false) {
			echo "There was an error saving your message!\n";
		}//end of if ($song_file ===false)

		else{
			fwrite($song_file, $songs_to_add);
			fclose($song_file);
			echo "Your song has been added to the list\n";
		}//end of else fwrite($song_file, $songs_to_add);
	}//end of else $song_file = fopen("SongOrganizer/songs.txt", "ab");
}//end of if(isset($_POST['submit']

	if ((!file_exists("SongOrganizer/songs.txt")) || (filesize("SongOrganizer/songs.txt")== 0)) {
			echo "<p>There are no songs in the list.</p>\n";
		}//end of if ! file_exists
		else{
			$song_array = file("SongOrganizer/songs.txt");
			echo "<table border=\"1\"width=\"100%\" style=\"background-color: lightgray\">\n";

			foreach($song_array as $Song){
				echo "<tr>\n";
				echo "<td>" . htmlentities($Song) . "</td>";
				echo "</tr>\n";
			}//end of foreach loop

			echo "</table>\n";
}//end of else


?>
<!-- Displaying hyperlinks for the three functions in the switch statment -->
<p>
<a href = "SongOrganizer.php?action=Sort_Ascending">Sort Song List</a><br />

<a href = "SongOrganizer.php?action=Remove_Duplicates" >Remove Duplicates</a><br />

<a href = "SongOrganizer.php?action=Shuffle">Randomize Song List</a><br />
</p>

<!--Web Form for entering song names into the song list  -->
<form action= "song_organizer.php" method = "post">
<p>Add a New Song</p>

<p>Song Name: <input type = "text" name = "SongName"/></p>

<p>
<input type = "submit" name = "submit" value = "Add Song to List"/>
<input type = "reset" name = "reset" value = "Reset Song Name">
</p>

</form>
</body>
</html>